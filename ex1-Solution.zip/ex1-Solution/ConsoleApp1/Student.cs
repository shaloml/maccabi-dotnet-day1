﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Student
    {
        public int SchoolID { get; set; }

        public string StudentName { get; set; }

        public int Price { get; set; }
    }
}
