﻿namespace WebApplication4
{
    public class GeneralSettings
    {
        public const string SECTION_NAME = "generalSettings";
        public string Name1 { get; set; }

        public int Name2 { get; set; }
    }
}