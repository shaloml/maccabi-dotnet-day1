using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace WebApplication4
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();

            #region Example1 
            services.Configure<GeneralSettings>(Configuration.GetSection(GeneralSettings.SECTION_NAME));
            services.AddSingleton<GeneralSettings>(p => p.GetService<IOptions<GeneralSettings>>().Value);
            #endregion

            #region Example2

           // Example #2: Options bound and configured by a delegate
            //services.Configure<GeneralSettings>(MySettings =>
            //{
            //    MySettings.Name1 = "value1_configured_by_delegate";
            //    MySettings.Name2 = 500;
            //});

            #endregion

            #region  Example3
            /*
            // Example #3: Suboptions
            // Bind options using a sub-section of the appsettings.json file.
            services.Configure<MySubSettings>(Configuration.GetSection("subsection"));
            */
            #endregion

            #region  Example4
            // Example #4: Named options (named_options_1)
            // Register the ConfigurationBuilder instance which MyOptions binds against.
            // Specify that the options loaded from configuration are named
            services.Configure<GeneralSettings>("named_options_1", Configuration);
            #endregion

            #region  Example5
            // Example #5: Named options (named_options_2)
            // Specify that the options loaded from the MyOptions class are named
            // "named_options_2".
            //  Use a delegate to configure option values.
            //services.Configure<MySettings>("named_options_2", myOptions =>
            //{
            //    myOptions.Name1 = "named_options_2_value1_from_action";
            //});
            #endregion


        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
