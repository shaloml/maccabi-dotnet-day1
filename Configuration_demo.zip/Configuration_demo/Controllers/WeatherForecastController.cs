﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace WebApplication4.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {


        private readonly ILogger<WeatherForecastController> _logger;
        private readonly GeneralSettings _optionSetting;
        //private readonly IOptionsSnapshot<MySubOptions> _subOptionSetting;

        // private readonly MySettings _named_options_1;
        //private readonly MySettings _named_options_2;

        public WeatherForecastController(ILogger<WeatherForecastController> logger, GeneralSettings setting)
        {
            _logger = logger;
            this._optionSetting = setting;
            //this._subOptionSetting = subOptionSetting;
            //this._named_options_1 = optionSetting.Get("named_options_1");
            //this._named_options_2 = optionSetting.Get("named_options_2");
        }


        [HttpGet]
        public string Get()
        {
            //return _subOptionSetting.CurrentValue.SubOption1;

             return _optionSetting.Name1;

            //return _named_options_1.Name1;

            //return _named_options_2.Name1;
        }
    }
}
